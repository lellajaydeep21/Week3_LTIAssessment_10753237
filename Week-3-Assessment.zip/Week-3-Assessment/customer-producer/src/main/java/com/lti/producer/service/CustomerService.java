package com.lti.producer.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.producer.dao.CustomerDao;
import com.lti.producer.model.Customer;
@Service
@Transactional
public class CustomerService {
	@Autowired
	CustomerDao dao;

	public Iterable<Customer> getAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return dao.save(customer);
	}

	public boolean deleteById(int id) {
		// TODO Auto-generated method stub
		if(dao.findById(id) != null) {
			dao.deleteById(id);
			return true ;
		}
		
	
		
		return false ;
	}

	public Optional<Customer> findById(int id) {
		// TODO Auto-generated method stub
		
		return dao.findById(id);
	}

	public Customer getById(int id) {
		// TODO Auto-generated method stub
		if(dao.findById(id) != null) {
			dao.getById(id);
			
		}
		return dao.getById(id) ;
	}

}
