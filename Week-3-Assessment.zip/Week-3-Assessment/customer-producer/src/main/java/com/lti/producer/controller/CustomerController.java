package com.lti.producer.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.producer.dao.CustomerDao;
import com.lti.producer.model.Customer;
import com.lti.producer.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@CrossOrigin(origins = "*")
@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@GetMapping("/customer/{id}")
	public ResponseEntity<Optional<Customer>> getCustomerbyid(@PathVariable ("id") long id) {
		Optional<Customer> cust=customerService.findById((int) id);
		return ResponseEntity.ok(cust);
	}
	
	@PutMapping("/updateById/{id}")
	public ResponseEntity<Customer>  updateById(@PathVariable ("id") long id,@RequestBody Customer customer) {
		
		Customer cust=customerService.getById((int)id);
		cust.setName(customer.getName());
		cust.setAccount(customer.getAccount());
		cust.setAddress(customer.getAddress());
		cust.setAge(customer.getAge());
		customerService.createCustomer(cust);
		return ResponseEntity.ok(customerService.createCustomer(cust));
	}
	
	
	@GetMapping("/getAllCustomerDetails")
	@HystrixCommand(fallbackMethod = "customerFallbackGetAll")
	public List<Customer> getAll(){
		return (List<Customer>) customerService.getAll();
	}
	
	@PostMapping("/createCustomer")
	@HystrixCommand(fallbackMethod = "CreateFallback")
	public Customer create(@RequestBody Customer customer) {
	return 	customerService.createCustomer(customer);
	}
	
	@PutMapping("/updateCustomer")
	@HystrixCommand(fallbackMethod = "customerFallbackUpdate")
	public String updateCustomer(@RequestBody Customer customer) {
		Customer obj=new Customer();
		obj.setId(customer.getId());
		obj.setName(customer.getName());
		obj.setAge(customer.getAge());
		obj.setAccount(customer.getAccount());
		obj.setAddress(customer.getAddress());
		customerService.createCustomer(obj);
		
		return "updated successflly";
		
	}
	@DeleteMapping("/delete/{id}")
	@HystrixCommand(fallbackMethod = "customerFallback")
	public boolean deleteById(@PathVariable("id") int id) {
		return customerService.deleteById(id);
	}
	
		
	
	
	public List<Customer> customerFallbackGetAll(){
		List<Customer> customer= new ArrayList<>();
		Customer fallback= new Customer();
		fallback.setName("fallback Customer");
		fallback.setAddress("fallback address");
		fallback.setAge(17);
		fallback.setId(5);
		fallback.setAccount("fallback account");
		customer.add(fallback);
		return customer;
	}

    public boolean customerFallback(int id) {
    	System.out.println("Customer service is down !!! fallback is enabled...." + id);
    	return true;
    }
	
    public String customerFallbackUpdate(Customer cust ) {
    	return "Customer service is down !!! fallback is enabled....";
    }
    
    public Customer CreateFallback(Customer cust) {
    	Customer fallback= new Customer();
		fallback.setName("fallback Customer");
		fallback.setAddress("fallback address");
		fallback.setAge(17);
		fallback.setId(5);
		fallback.setAccount("fallback account");
		return fallback;
    	
    }

}
