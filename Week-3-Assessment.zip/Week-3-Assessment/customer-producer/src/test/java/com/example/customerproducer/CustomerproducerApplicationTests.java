package com.example.customerproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
