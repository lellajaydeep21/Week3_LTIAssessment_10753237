export class Customer {
    id:any;
    name:any;
    age:any;
    address:any;
    account:any;
    active: any;
}
