package com.lti.consumer.entity;

public class customer {
	
	public int id;
	
	public String name;
	
	public int age;
	
	public String address;
	
	public String account;
	
	public customer() {
		
	}

	public customer(int id, String name, int age, String address, String account) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.address = address;
		this.account = account;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}
	
	
	

}
