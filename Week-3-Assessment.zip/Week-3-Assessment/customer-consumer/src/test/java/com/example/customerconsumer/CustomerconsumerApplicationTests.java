package com.example.customerconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
